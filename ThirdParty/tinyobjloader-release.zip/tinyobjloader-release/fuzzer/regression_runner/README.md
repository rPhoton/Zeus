# Run fuzzer regression tests

Currently we only support Linux + clang.

## How to run

```
$ make
$ ./a.out ../regressions/<regression_file>
```

